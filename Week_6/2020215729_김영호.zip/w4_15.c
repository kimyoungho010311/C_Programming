#define _CTR_SECURE_NO_WARNINGS
#include <stdio.h>

int main(void)
{

    unsigned int num;
    printf("십진수 : ");
    scanf("%u", &num);

    unsigned int mask = 1 << 7;
    printf("이진수 : ");
    ((num & mask) == 0) ? printf("0") : printf("1");
    mask = mask >> 1;
    ((num & mask) == 0) ? printf("0") : printf("1");
    mask = mask >> 1;
    ((num & mask) == 0) ? printf("0") : printf("1");
    mask = mask >> 1;
    ((num & mask) == 0) ? printf("0") : printf("1");
    mask = mask >> 1;
    ((num & mask) == 0) ? printf("0") : printf("1");
    mask = mask >> 1;
    ((num & mask) == 0) ? printf("0") : printf("1");
    mask = mask >> 1;
    ((num & mask) == 0) ? printf("0") : printf("1");
    mask = mask >> 1;
    ((num & mask) == 0) ? printf("0") : printf("1");
    printf("\n");
}