#include <stdio.h>

int main(void)
{
    int x, y, prod;
    scanf("%d", &x);
    scanf("%d", &y);
    prod = x * y;
    printf("곱셈의 결과 = %d", prod);
    return 0;
}