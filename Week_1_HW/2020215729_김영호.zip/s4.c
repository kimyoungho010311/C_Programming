// (a)
// It's never too late.
// it never rains but it pours.

// (b)
// 10

// (c)
// 30

// (d)
// 10 + 20 = 30

// (e)
// 10 * 20 = 20

// (f)
// *
// **
// ***
// ****