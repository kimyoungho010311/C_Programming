#include <stdio.h>

int main()
{

    int num = 0;

    printf("아스키 코드값을 입력하시오 : ");
    scanf("%d", &num);

    printf("\n문자 %c입니다.", num);

    return 0;
}