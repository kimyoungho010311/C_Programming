#include <stdio.h>

int main()
{

    float result = 3.32e-3 + 9.76e-8;

    printf("%f", result);

    return 0;
}