#include <stdio.h>

int main()
{

    int a = 97;
    int b = 97 + 1;
    int c = 97 + 2;
    int d = 97 + 3;

    printf("%c %c %c", b, c, d);

    return 0;
}