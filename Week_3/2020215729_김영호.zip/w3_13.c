#include <stdio.h>

int main(void)
{

    char code1 = 'A';
    char code2 = 65;

    printf("code1 = %c\n", code1);
    printf("code2 = %c\n", code2);

    return 0;
}