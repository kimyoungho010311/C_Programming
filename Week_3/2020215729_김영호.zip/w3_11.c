#include <stdio.h>

int main(void)
{

    float value = 0.1;

    printf("%.20f\n", value);

    return 0;
}