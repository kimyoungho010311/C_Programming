// #include <stdio.h>

// int main(void)
// {

//     float radius, area;

//     printf("반지름을 입력 : ");
//     scanf("%lf", &radius);

//     area = 3.14 * radius * radius;
//     printf("원의 넓이는 : %d", area);

//     return 0;
// }