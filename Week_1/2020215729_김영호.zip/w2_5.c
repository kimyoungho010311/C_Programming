// #include <stdio.h>

// int main(void)
// {

//     double rate, usd;
//     int krw;

//     printf("환율을 입력하세요 : ");
//     scanf("%lf", &rate);

//     printf("원화 금액 입력 : ");
//     scanf("%d", &krw);

//     usd = krw / rate;

//     printf("원화 %d원은 %lf달러입니다.\n", krw, usd);

//     return 0;
// }